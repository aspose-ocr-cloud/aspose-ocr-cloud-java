/*
* --------------------------------------------------------------------------------------------------------------------
* <copyright company="Aspose" file="ConversionApi.java">
*   Copyright (c) 2020 Aspose.OCR for Cloud
* </copyright>
* <summary>
*   Permission is hereby granted, free of charge, to any person obtaining a copy
*  of this software and associated documentation files (the "Software"), to deal
*  in the Software without restriction, including without limitation the rights
*  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
*  copies of the Software, and to permit persons to whom the Software is
*  furnished to do so, subject to the following conditions:
*
*  The above copyright notice and this permission notice shall be included in all
*  copies or substantial portions of the Software.
*
*  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
*  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
*  SOFTWARE.
* </summary>
* --------------------------------------------------------------------------------------------------------------------
*/

package com.aspose.ocr.api;

import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.*;

public interface OcrApi {

    /**
     * Recognize image text from some www URL
     * @param url    Image URL in the World Wide Web (required)
     * @return Call<ResponseBody>
     */
    @Headers({"Content-Type:application/json"})
    @POST("ocr/recognize")
    Call<ResponseBody> RecognizeFromUrl(
            @Query("url") String url
    );

    /**
     * Recognize image text from some www URL
     * @param url       Image URL in the World Wide Web (required)
     * @param language  Set recognition language. (optional)
     * @return Call<ResponseBody>
     */
    @Headers({"Content-Type:application/json"})
    @POST("ocr/recognize")
    Call<ResponseBody> RecognizeFromUrl(
            @Query("url") String url,
            @Query("language") Language language
    );

    /**
     *  Recognize image text from the request body content. Send image on recognition directly.
     * @param file  Request body with file in content as octet-stream (required)
     * @return Call<ResponseBody>
     */
    @POST("ocr/recognize")
    Call<ResponseBody> RecognizeFromContent(
            @Body RequestBody file
    );

    /**
     *  Recognize image text from the request body content. Send image on recognition directly.
     * @param file      Request body with file in content as octet-stream (required)
     * @param language  Set recognition language. (optional)
     * @return Call<ResponseBody>
     */
    @POST("ocr/recognize")
    Call<ResponseBody> RecognizeFromContent(
            @Body RequestBody file,
            @Query("language") Language language
    );

    /**
     * Put image in Aspose Cloud Storage and Recognise
     *
     * @param name         Document name. (required)
     * @param folder       The source document folder for storage. (optional)
     * @param storage      The storage name in Aspose Cloud. (optional)
     * @return Call<ResponseBody>
     */
    @GET("ocr/{name}/recognize")
    Call<ResponseBody> RecognizeFromStorage(
            @Path("name") String name,
            @Query("storage") String storage,
            @Query("folder") String folder
    );

    /**
     * Put image in Aspose Cloud Storage and Recognise
     *
     * @param name         Document name. (required)
     * @param folder       The source document folder for storage. (optional)
     * @param storage      The storage name in Aspose Cloud. (optional)
     * @param language     Set recognition language. (optional)
     * @return Call<ResponseBody>
     */
    @GET("ocr/{name}/recognize")
    Call<ResponseBody> RecognizeFromStorage(
            @Path("name") String name,
            @Query("folder") String folder,
            @Query("storage") String storage,
            @Query("language") Language language
    );

}
